package com.example.pr26;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Идентификатор уведомления
    private static final int NOTIFY_ID = 101;

    // Идентификатор канала
    private static final String CHANNEL_ID = "Cat channel";

    // CharSequence CHANNEL_NAME = getString(R.string.channel_name);
    // int importance = NotificationManager.IMPORTANCE_LOW;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button2);
        button.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        //  NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME,importance);

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(MainActivity.this, CHANNEL_ID)
                        .setContentTitle("Напоминание")
                        .setSmallIcon(R.drawable.baseline_scatter_plot_24)
                        .setContentText("Пора покормить кота")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setOngoing(true);


        NotificationManagerCompat notificationManager =
                NotificationManagerCompat.from(MainActivity.this);

        notificationManager.notify(NOTIFY_ID, builder.build());

    }


}